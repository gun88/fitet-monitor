<?php

require_once FITET_MONITOR_DIR . 'admin/includes/class-fitet-monitor-page.php';
require_once FITET_MONITOR_DIR . 'admin/components/club-table/class-fitet-monitor-club-table-component.php';

class Fitet_Monitor_Summary_Page extends Fitet_Monitor_Page {

	private $clubs;

	public function __construct($plugin_name, $version, $clubs) {
		parent::__construct($plugin_name, $version);
		$this->clubs = $clubs;
	}

	public function components() {
		return ['table' => new Fitet_Monitor_Club_Table_Component($this->plugin_name, $this->version)];
	}

	public function initialize_data() {

		return [
			'pageTitle' => get_admin_page_title(),
			'proxyUrl' => esc_attr(get_option('fitet_monitor_proxy_url', '')),
			'proxyAction' => esc_url(menu_page_url('fitet-monitor', false)),
			'proxyNonce' => wp_nonce_field('fitet_monitor_save_proxy', '_wpnonce', true, false),
			'matchDisplayNonce' => wp_nonce_field('fitet_monitor_match_display', '_wpnonce', true, false),
			'matchIframeChecked' => get_option('fitet_monitor_match_display', 'native') === 'iframe' ? 'checked' : '',
			'addButton' => __('Add Club', 'fitet-monitor'),
			'messagePool' => $this->prepare_messages(),
			'table' => $this->components['table']->render($this->clubs)];
	}

	public function prepare_messages() {
		$messagePool = '';
		if (isset($_GET['message']) && 'proxy_saved' === $_GET['message']) {
			$messagePool = '<div class="updated notice is-dismissible"><p>Proxy salvato.</p></div>';
		}
		if (isset($_GET['message']) && 'match_display_saved' === $_GET['message']) {
			$messagePool = '<div class="updated notice is-dismissible"><p>Modalità incontri salvata.</p></div>';
		}
		if (isset($_GET['message']) && 'invalid_proxy' === $_GET['message']) {
			$messagePool = '<div class="error notice is-dismissible"><p>Inserisci un URL HTTP o HTTPS senza percorso, ad esempio http://93.49.76.69:18080/.</p></div>';
		}
		if (isset($_GET['message']) && 'proxy_test' === $_GET['message']) {
			$key = 'fitet_monitor_proxy_test_' . get_current_user_id();
			$results = get_transient($key);
			delete_transient($key);
			if (is_array($results)) {
				$messagePool = '<div class="notice notice-info is-dismissible"><p>' . implode('<br>', array_map('esc_html', $results)) . '</p></div>';
			}
		}
		if (isset($_GET['message']) && 'deleted' === $_GET['message']) {
			$messagePool = '<div id="message" class="updated notice is-dismissible"><p>' . __('Delete operation completed', 'fitet-monitor') . '</p></div>';
		}
		if (isset($_GET['message']) && 'added' === $_GET['message']) {
			$messagePool = '<div id="message" class="updated notice is-dismissible"><p>' . __('Club added successfully', 'fitet-monitor') . '</p></div>';
		}
		if (isset($_GET['message']) && 'edited' === $_GET['message']) {
			$messagePool = '<div id="message" class="updated notice is-dismissible"><p>' . __('Club edited successfully', 'fitet-monitor') . '</p></div>';
		}
		return $messagePool;
	}


}
