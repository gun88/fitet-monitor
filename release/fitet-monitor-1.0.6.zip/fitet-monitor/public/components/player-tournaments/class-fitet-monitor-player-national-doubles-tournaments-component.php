<?php

require_once FITET_MONITOR_DIR . 'common/includes/class-fitet-monitor-component.php';
require_once FITET_MONITOR_DIR . 'public/components/table/class-fitet-monitor-table-component.php';
require_once FITET_MONITOR_DIR . 'public/components/cells/class-fitet-monitor-player-cell-component.php';


class Fitet_Monitor_Player_National_Doubles_Tournament_Component extends Fitet_Monitor_Component {

	protected function components() {
		return [
			'table' => new Fitet_Monitor_Table_Component($this->plugin_name, $this->version),
			'playerCell' => new Fitet_Monitor_Player_Cell_Component($this->plugin_name, $this->version),
		];
	}

	protected function process_data($data) {
		$table = [
			'name' => 'national-doubles-tournaments',
			'columns' => $this->columns(),
			'sort' => $this->sort(),
			'rows' => $this->rows($data),
		];

		return [
			'nationalDoubleTournamentsLabel' => __('National Double Tournaments', 'fitet-monitor'),
			'table' => $this->components['table']->render($table),
		];
	}

	public function columns() {
		return [
			'season' => __("Season", 'fitet-monitor'),
			'date' => __("Date", 'fitet-monitor'),
			'partner' => __("Doubles Partner", 'fitet-monitor'),
			'competition' => __("Competition", 'fitet-monitor'),
			'round' => __("Round", 'fitet-monitor')
		];
	}

	public function sort() {
		return [
			'date' => 'date',
			'round' => 'number',
		];
	}

	public function rows($data) {
		return array_map(function ($row) use ($data) {
			$row['partner'] = $this->components['playerCell']->render(['playerId' => $row['partnerPlayerId'], 'playerName' => $row['partnerPlayerName'], 'playerPageUrl' => $row['partnerPlayerPageUrl']]);
			$row['competition'] = $this->competition($row['competition'], $row['tournament']);
			return $row;
		}, $data['history']['nationalDoublesTournaments']);
	}


	private function competition($competition, $tournament) {
		return "<b>$tournament</b><br><span>$competition</span>";
	}


}
