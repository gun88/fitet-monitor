<?php

require_once FITET_MONITOR_DIR . 'common/includes/class-fitet-monitor-component.php';

class Fitet_Monitor_Progress_Bar_Component extends Fitet_Monitor_Component {

}
